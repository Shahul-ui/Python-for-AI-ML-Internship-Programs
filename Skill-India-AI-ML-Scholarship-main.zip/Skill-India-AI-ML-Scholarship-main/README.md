# Skill-India-AI-ML-Scholarship
This repository is having all the codes used in AI/ML Skill India Scholarship by Elite Techno Groups.

-----
### About the Repository?

You'll learn Python, Data Structure, Data Handling, File Handling, JSON, Numpy, Pandas, Data Visualizations, Data Analysis and AI Algorithms to make Breast Cancer Detection.

-----

### Who am I?

My name is Ashish and I'm an AI Trainer at Teenage Coder, and on the side, I make YouTube videos about coding and tech. I'm also working as an AI trainer at Elite Techno Groups and made India's first Self Driving Cars course with them. I've trained more than 10000 students on different technologies like AI, Data Science, Computer Vision, and the Internet of Things. I'm passionate about teaching and giving students the skillset to learn cutting-edge skills.

-----

### Other Useful Links:

LinkedIn - https://linkedin.com/in/ashish-jangra 

Instagram - https://instagram.com/ashish_zangra 

Facebook - https://facebook.com/ashishzangra
